import java.util.Random;
import java.util.Scanner;
import java.util.UUID;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        byte b = (byte) rnd.nextInt(); //приведения переменной типа  byte к int.
        short s = (short) rnd.nextInt(); //приведения переменной типа  short к int.
        int i = rnd.nextInt();
        long l = rnd.nextLong();
        float f = rnd.nextFloat();
        double d = rnd.nextDouble();
        char c = (char) rnd.nextInt(); //приведения переменной типа  char к int.
        boolean boo = rnd.nextBoolean();
        System.out.println(b +", "+ s +", "+ i +", "+ l+", " + f+", " + d+", "+ c);
        System.out.println(boo);


        // дз1 часть 2
        String str1 = UUID.randomUUID().toString();
        String str2 = String.valueOf(rnd.nextInt());
        System.out.println(str1);
        System.out.println(str2);
        }

}