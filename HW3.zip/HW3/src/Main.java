import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите число a ");
        int a = scr.nextInt();
        System.out.println("Введите число b ");
        int b = scr.nextInt();
        System.out.println((a+b) + "," + (a-b) + "," + (a*b) + "," + (a/b));

    }
}