import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.print("Введите ваше имя: ");
        String name = scr.nextLine();
        System.out.print("Введите ваш возраст: ");
        int age = scr.nextInt();
        System.out.print("Введите ваш вес: ");
        float weight = scr.nextFloat();
        System.out.printf("Уважаемый, %s! В свои %d лет Вы для нас дороги, как %f киллограм золота",name, age, weight);
    }
}