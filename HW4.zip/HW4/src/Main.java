import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        double a = Math.random();
        double b = Math.random();
        System.out.println("Рандомные числа " + a + " и " + b);
        System.out.println("Разница по модулю " + Math.abs(a-b));
        System.out.println("минимальное из двух " + Math.min(a,b));
        System.out.println("Максимальное из двух " + Math.max(a,b));
        System.out.println("Возведение первого числа в степень " + Math.pow(a,b*10));


    }
}